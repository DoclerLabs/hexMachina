# hexMachinaBundle
[![TravisCI Build Status](https://travis-ci.org/DoclerLabs/hexMachina.svg?branch=master)](https://travis-ci.org/DoclerLabs/hexMachina) Contains the full hexMachina framework

*Find more information about hexMachina on [hexmachina.org](http://hexmachina.org/)*
